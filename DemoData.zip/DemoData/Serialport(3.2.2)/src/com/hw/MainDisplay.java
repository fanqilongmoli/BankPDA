package com.hw;

import android.opengl.Visibility;
import android.os.Bundle;
import android.os.Message;
import android.os.PowerManager;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.os.Handler;
import android.os.SerialPortServiceManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Vector;

@SuppressLint("HandlerLeak")
public class MainDisplay extends Activity  implements OnClickListener{
	// ����
	public static final String TAG = "Serialport-APP";
	private static final int DISPLAY_READ_HEX     = 0x000;
	private static final int DISPLAY_READ_ASC     = 0x001;
	private static final int DISPLAY_READ_HEX_F   = 0x002;
	private static final int DISPLAY_READ_ASC_F   = 0x003;
	private static final int DISPLAY_WRITE_HEX    = 0x010;
	private static final int DISPLAY_WRITE_ASC    = 0x011;
	private static final int ACTION_SCREEN_ON     = 0x100;
	private static final int ACTION_SCREEN_OFF    = 0x101;
	private static final int ACTION_MESSAGE_ERROR = 0xfff;
	private static final int Message_display 	  = 0x010;
	private static final int TX_display 			  = 0x011;
	
	// cmd index
	public static final int cmd_input = 0x2;
	public static final int cmd_out   = 0x3;
	public static final int gps_power_off  = 0x100;
	public static final int gps_power_on   = 0x101;
	public String power_cmd[] = new String[4];
	public String power_path[] = new String[32];
	
	
	// find node
	Vector<File> mDevices = null;
	
	// ������
	public PowerManager pm ;
	public PowerManager.WakeLock mWakeLock;
	
	// ���յ�����ʱclean��fastģʽʱ��
	public static final int rx_max = 10000;
	
	// ���� ��
	private static Object rxlock = new Object();
	
	// SD��·��
	// private static String sd_dir = "/mnt/sdcard/external_sdcard/SerialportLog/";
	private static String sd_dir = "/storage/sdcard1/SerialportLog/";
	private static File   file ;
	private static int    sd_state_flag = 0;
	private static boolean enableMKDir = false;
	
	
	String RFID_POWER_PATH = "/proc/gpiocontrol/set_id";
	String SCAN_EN_PATH = "/proc/gpiocontrol/set_en";
	String PSAM_POWER_PATH = "/proc/gpiocontrol/set_sam";
	
    // д�����
	public static byte[]  part_serialPortNode = null;
	public static int     part_baud = 0;
	public static int     part_data_size = 8;
	public static int     part_stop_bit = 1;
	public static int     part_display_hex_asc = DISPLAY_READ_ASC;
	private Handler mHandler = null;
	
	// ���Ҵ������
	public List<String> allNode;

	// �ؼ�
	private Spinner 		baud_spinner  = null;
	private Spinner 		node_spinner  = null;
	private Spinner 		disp_spinner  = null;
	private TextView       	curDisplay    = null;
	private TextView        rxDisplay 	  = null;
	private TextView        txDisplay 	  = null;
	private EditText        sendText      = null;
	private CheckBox        send_hex      = null;
	private CheckBox        send_auto     = null;
	private EditText        send_auto_time= null;
	private int             _Dbug_ = 1;
	private int             get_auto_time = 0;
	
	// ��չ�ؼ�
	private Spinner         cur_soc = null;
	private ToggleButton    cur_bd_power = null;
	private ToggleButton    cur_update   = null;
	
	// �Ի���ؼ�
	private  LayoutInflater dg_li = null;
	private  LayoutInflater dg_power = null;
	private  View dg_view = null;
	private Spinner     dg_spinner_gp  = null;
	private Spinner     dg_spinner_num = null;
	private Spinner     dg_spinner_st  = null;
	
	private int         dg_gpio_group = 0;
	private int         dg_gpio_num = 0;
	private int         dg_gpio_st = 0;
	private DialogInterface.OnClickListener dialog_wirte;
	private byte[] 		cmd_buffer = new byte[10];
	private int         dg_ret;
	
	// �㲥������
	private MreceiveBC     curMreceiveBC    = new MreceiveBC();
	private IntentFilter   cur_IntentFilter = new IntentFilter(Intent.ACTION_MEDIA_EJECT);
	private IntentFilter   cur_Screen_Rece  = new IntentFilter(Intent.ACTION_SCREEN_OFF);
	private static    int  broadf = 0;
	
	private String[]  baud_string;
//	private String[]  node_string;
	private String[]  disp_string;
	// node for adapter
	private ArrayAdapter<String> node_adapter;
	
	private int cur_module = 0;
	
	//�洢����
	private Context ctx; 
	private SharedPreferences sp;
	private Editor editor;
	
	
	// ��ť
	private Button    node_open;
	private Button    node_close;
	private Button    node_clean;
	private Button    node_send;
	private Button    node_ext;
	private Button    node_save;
	private Button    node_setting;
	
	//����ҳ�����Բ���
	private LinearLayout layout_setting;
	
	//��չ������
	private LinearLayout.LayoutParams ext_params = new LinearLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		
	// ������
	private ScrollView mScrollView;
	private int       sum_rx = 0;
	private int       sum_tx = 0;
	private LinearLayout cur_man_exten;
	
	private SerialPortServiceManager   mSeriport;
	private read_thread   mreadTh;
	private auto_send_thread   mreadTh_auto;
	
	private byte[] read_buffer = new byte[1024];
	private byte[] write_buffer= new byte[1024];
	
	private int ret = 0;
	private int open_state_before = 0;
	private int flag_ext = 0;
	
	// ʱ�������
	private static SimpleDateFormat sDateFormat = new  SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");
	
	// ʮ�����ƹ���
	private static final String regEx      = "[0-9a-fA-F]*";
	private static final String regEx_auto = "[0-9]*";
	
	Queue<String> rx_queue = new LinkedList<String>();
	private String head_queue = null;
	
    public void update_device_node()
    {
    	// �����豸
    	Iterator<File> itrDevice_usb = getDevices("/dev/ttyUSB").iterator();
    	Iterator<File> itrDevice_acm = getDevices("/dev/ttyACM").iterator();
    	allNode = new ArrayList<String>(); 
    	allNode.add("ttyS0");
    	allNode.add("ttyS1");
    	allNode.add("ttyS2");
    	allNode.add("ttyS3");
    	// find usb serialport devices..
    	while (itrDevice_usb.hasNext()) {
    		allNode.add(itrDevice_usb.next().getName());
    	}
    	// find acm serialport devices..
    	while (itrDevice_acm.hasNext()) {
    		allNode.add(itrDevice_acm.next().getName());
    	}
    		
    	node_adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, allNode);  
    	node_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); 
    	      
    	node_spinner.setAdapter(node_adapter);
    	node_spinner.setSelection(0, true);
    }
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_display);
		
		// ------------------> set ui
		Resources res =getResources();
		baud_string = res.getStringArray(R.array.baud);
		// node_string = res.getStringArray(R.array.index);
		disp_string = res.getStringArray(R.array.display);

		node_spinner = (Spinner)findViewById(R.id.spinner_node);
		baud_spinner = (Spinner)findViewById(R.id.spinner_baud);
		disp_spinner = (Spinner)findViewById(R.id.spinner_display);
		
		cur_soc    = (Spinner)findViewById(R.id.spinner_soc);
		
		node_open  = (Button)findViewById(R.id.button_open);
		node_send  = (Button)findViewById(R.id.button_send);
		node_ext   = (Button)findViewById(R.id.button_ext);
		node_save  = (Button)findViewById(R.id.button_save);
		node_close = (Button)findViewById(R.id.button_close);
		node_clean = (Button)findViewById(R.id.button_clean);
		node_setting = (Button) findViewById(R.id.btn_setting);
		
		layout_setting = (LinearLayout) findViewById(R.id.linear_setting);
		
		curDisplay = (TextView)findViewById(R.id.display_rx);
		rxDisplay  = (TextView)findViewById(R.id.text_st_rx);
		txDisplay  = (TextView)findViewById(R.id.text_st_tx);
		sendText   = (EditText)findViewById(R.id.text_send);
		send_hex   = (CheckBox)this.findViewById(R.id.cb_send_hex);
		send_auto  = (CheckBox)this.findViewById(R.id.cb_send_auto);
		mScrollView= (ScrollView)findViewById(R.id.sv_show);
		send_auto_time = (EditText)findViewById(R.id.text_auto_time);
		
		// UI ������չ
		cur_bd_power = (ToggleButton)findViewById(R.id.button_bd);
		cur_update   = (ToggleButton)findViewById(R.id.button_update);
		
		cur_man_exten = (LinearLayout)findViewById(R.id.line_man_extend);
		cur_man_exten.setVisibility(View.GONE);
		flag_ext = 0;
		ext_params.weight = 6.0f;
		findViewById(R.id.layout_fun).setLayoutParams(ext_params);
	
		// ����
		 pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		 mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "My Tag"); 

		// С�� ���ݴ洢��
		//��ȡSharedPreferences����
	    ctx = MainDisplay.this;       
	    sp = ctx.getSharedPreferences("exp_data", MODE_PRIVATE);
	    editor = sp.edit();
		
		// hex ����¼�
		send_hex.setOnCheckedChangeListener(new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				sendText.setText("");
			}
		});
		
		send_auto.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
			{
				// TODO Auto-generated method stub
				if(isChecked) {
					String cur_auto_time = send_auto_time.getText().toString();
					cur_auto_time = cur_auto_time.replace(" ", "");
					if(cur_auto_time.length() > 0)
					{
						if(cur_auto_time.matches(regEx_auto)) {
							get_auto_time =  Integer.parseInt(cur_auto_time);
						} else {
							send_auto.setChecked(false);
						}
					}
				} else {
					Log.d("TAG", "--------------->no auto");
				}
			}
		});
		
		// ---------------------> ����������
		node_spinner.setOnItemSelectedListener(cur_Item_select);
		baud_spinner.setOnItemSelectedListener(cur_Item_select);
		disp_spinner.setOnItemSelectedListener(cur_Item_select);
		cur_soc.setOnItemSelectedListener(cur_Item_select);
		node_spinner.setPrompt("ѡ���豸�ڵ�");
		baud_spinner.setPrompt("ѡ������");
		disp_spinner.setPrompt("ѡ����ʾ��ʽ");
		cur_soc.setPrompt("ѡ��оƬģ��");
		baud_spinner.setSelection(7, true);
		disp_spinner.setSelection(1, true);
		cur_soc.setSelection(0,true);
		
		update_device_node();
		
        power_cmd[0] = "gps";
        power_cmd[1] = "qrscan";
        power_cmd[2] = "rfid";
        power_cmd[3] = "fprint";
        
        power_path[0] = RFID_POWER_PATH;
        power_path[1] = SCAN_EN_PATH;
        power_path[2] = PSAM_POWER_PATH;
        power_path[3] = "";      
        
		// �����ļ��� 
		Log.d(TAG,"--->start to open file!");
		file = new File(sd_dir); 
		if(!file.exists()) {
			enableMKDir = file.mkdirs();
			if(enableMKDir == false) {
				Log.d(TAG,"--->log dir mkdir fail!");
			}
		} else {
			enableMKDir = true;
			Log.d(TAG,"--->log dir is exists!");
		}

		// �㲥�������ã�
		if(broadf == 0) {
			cur_Screen_Rece.addAction(Intent.ACTION_SCREEN_ON);
			cur_IntentFilter.addAction(Intent.ACTION_MEDIA_MOUNTED);
			cur_IntentFilter.addDataScheme("file");
			registerReceiver(curMreceiveBC, cur_IntentFilter);
			registerReceiver(curMreceiveBC, cur_Screen_Rece);
			broadf = 1;
			Log.d(TAG,"-------->set broadcast receiver!");
		}
		
	    // ��ť�¼���
		node_open.setOnClickListener(this);
		node_send.setOnClickListener(this);
		node_ext.setOnClickListener(this);
		node_save.setOnClickListener(this);
		node_close.setOnClickListener(this);
		node_clean.setOnClickListener(this);
		
		node_close.setClickable(false);
		node_send.setClickable(false);
		node_ext.setClickable(true);
		
		// ȡ�ô��ڷ���
		mSeriport = new SerialPortServiceManager(0);//0--->colse log  1---->open log
		
		if(mSeriport == null) {
			Log.d(TAG, "------------------------>SerialPortServiceManager star fail!");
			node_open.setClickable(false);
		}
		
		// ------------------------------------------------>�Ի���ť�¼�
		dialog_wirte = new DialogInterface.OnClickListener() {
 
			@Override
		public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				if(which == DialogInterface.BUTTON_POSITIVE) {
					Log.d(TAG, "------------>" + dg_gpio_group + "  " + dg_gpio_num + "  " + dg_gpio_st);
					if(gpio_aml.gpio_check(dg_gpio_group, dg_gpio_num) == 0) {
						cmd_buffer[0] = (byte)gpio_aml.get_gpio_num(dg_gpio_group, dg_gpio_num);
						cmd_buffer[1] = (byte)dg_gpio_st;
						dg_ret = mSeriport.cmd(cmd_out, cmd_buffer);
						if(dg_ret == 0) {
							curDisplay.append("\n\n\nGPIO�ܽŲ����ɹ�\n\n\n");
						} else if(dg_ret < 0) {
							curDisplay.append("\n\n\nGPIO�ܽŲ���ʧ��\n\n\n");
						}
					} else {
						curDisplay.append("\n\n\n�����ڴ�GPIO�ܽ�\n\n\n");
					}
					mScrollView.scrollTo(0, curDisplay.getHeight());
				} else if(which == DialogInterface.BUTTON_NEGATIVE) {
					Log.d(TAG, "------------>dg_cancel");
				} else if(which == DialogInterface.BUTTON_NEUTRAL) {
					Log.d(TAG, "------------>dg_noknow");
				}
			}
		};
		
		// �߳���Ϣ���մ���------------------------------------------------>
		mHandler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				switch(msg.what) 
				{
					case Message_display:
						 int k = 0;
						 do {
							 synchronized (rxlock) {
								 head_queue = rx_queue.poll();
							 }
							 if(head_queue != null) {
								 if(part_display_hex_asc == DISPLAY_READ_HEX || part_display_hex_asc == DISPLAY_READ_HEX_F) {
									 
									 // curDisplay.append(help.toString(head_queue.getBytes(), 0, head_queue.length()));
									try {
										curDisplay.append(help.toString(head_queue.getBytes("iso-8859-1"), 0, head_queue.length()));
									} catch (UnsupportedEncodingException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								 } else if(part_display_hex_asc == DISPLAY_READ_ASC || part_display_hex_asc == DISPLAY_READ_ASC_F) {
									 curDisplay.append(head_queue);
								 } else if(part_display_hex_asc == 4) {
									 curDisplay.append(head_queue + "\n");
								 }
								 rxDisplay.setText("RX:" + sum_rx);
								 txDisplay.setText("TX:" + sum_tx);
								 
								
								 mScrollView.scrollTo(0, curDisplay.getHeight());
								 if(sum_rx > rx_max && (part_display_hex_asc == 2 || part_display_hex_asc == 3)) {
									 node_clean.performClick();
								 } else if(sum_rx > (rx_max * 3) && (part_display_hex_asc == 0 || part_display_hex_asc == 1)) {
									 node_save.performClick();
									 node_clean.performClick();
								 }
							} else {
								 break;
							 }
						 } while(k++ < 4);
						break;
					case TX_display:
						rxDisplay.setText("RX:" + sum_rx);
						 txDisplay.setText("TX:" + sum_tx);
						 break;
					case ACTION_SCREEN_ON:
						if(open_state_before == 1) {
							node_open.performClick();
						}
						open_state_before = 0;
						Log.d(TAG,"----------->Hand GET ACTION_SCREEN_ON!");
						break;
					case ACTION_SCREEN_OFF:
						if(open_state_before == 1) {
							node_close.performClick();
						}
						Log.d(TAG,"----------->Hand GET ACTION_SCREEN_OFF!");
						break;
					default:
						Log.d(TAG,"----------->message error:"+msg.what);
				}
			}
		};
		// ����һ���߳�
		mreadTh = new read_thread();
		mreadTh_auto = new auto_send_thread();
		
		mreadTh.start();
		mreadTh_auto.start();
	}
	
	public OnClickListener m_checkBox_list = new OnClickListener() {
		public void onClick(View arg0) {
			if (arg0.getId() == R.id.cb_send_auto)
			{
					;
			}
		}
	};
	
	
	public OnItemSelectedListener cur_Item_select = new OnItemSelectedListener()
	{
		@Override
		public void onItemSelected(AdapterView<?> arg0, View arg1,
				int arg2, long arg3) {
			// TODO Auto-generated method stub
			if(arg0 == node_spinner) {
				 part_serialPortNode = new String("/dev/" + (String)node_spinner.getSelectedItem() ).getBytes();
				// Log.d(TAG, (String)node_spinner.getSelectedItem());
				
			} else if (arg0 == baud_spinner){
				part_baud = Integer.parseInt(baud_string[arg2]);
			} else if (arg0 == disp_spinner){
				part_display_hex_asc = arg2;
			} else if (arg0 == dg_spinner_gp){
				dg_gpio_group = arg2;
			} else if(arg0 == dg_spinner_num) {
				dg_gpio_num = arg2;
			} else if(arg0 == dg_spinner_st) {
				dg_gpio_st = arg2;
			} else if(arg0 == cur_soc) {
				//cur_soc_type = arg2;
			//	Log.d(TAG, "cur_soc_type---------------->" + cur_soc_type);
				cur_bd_power.setChecked(false);
				cur_module = arg2;
				
				// -------------------------------------
				int curValue = 0;
				switch(cur_module)
				{
					case 0:
						curValue = sp.getInt("RFID_KEY", 0);
						break;
					case 1:
						curValue = sp.getInt("IR_KEY", 0);
						break;
					case 2:
						curValue = sp.getInt("ID_KEY", 0);
						break;
					case 3:
						curValue = sp.getInt("FG_KEY", 0);
						break;
					default:
						curValue = 0;
				}

				if(curValue == 0)
					cur_bd_power.setChecked(false);
				else
					cur_bd_power.setChecked(true);
					
				
				// ---------------------------
			} else {
				Log.d(TAG, "---------------->spinner select error");
			}
		}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// TODO Auto-generated method stub
			
		}
	};
	// �˵���-------------------------------------------------->
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		 getMenuInflater().inflate(R.menu.main_display, menu);
		 menu.add(Menu.NONE, Menu.FIRST + 1, 1, "δ����");
		 menu.add(Menu.NONE, Menu.FIRST + 2, 2, "δ����");
		 menu.add(Menu.NONE, Menu.FIRST + 3, 3, "δ����");
		 menu.add(Menu.NONE, Menu.FIRST + 4, 4, "δ����");
		 menu.add(Menu.NONE, Menu.FIRST + 5, 5, "δ����");	
		 
		return true;
	}
	
	public Vector<File> getDevices(String det) {
			mDevices = new Vector<File>();
			File dev = new File("/dev");
			File[] files = dev.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].getAbsolutePath().startsWith(det)) {
					mDevices.add(files[i]);
				    Log.e(TAG, "find new device:::" + files[i]);
				}
			}

		return mDevices;
	}
	
	 public boolean onOptionsItemSelected(MenuItem item) {
	        switch (item.getItemId()) {

	        case Menu.FIRST + 1: 
	        	Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	            break;
	        case Menu.FIRST + 2:// ---------------------------------------------------->GPS power ���ƣ�
	        	Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	            break;
	        case Menu.FIRST + 3:
	            Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	            break;
	        case Menu.FIRST + 4:
	            Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	            break;
	        case Menu.FIRST + 5:
	            Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	            break;
	        default :
	        	Toast.makeText(this, "δ����", Toast.LENGTH_LONG).show();
	        }
	        return false;
	    }
	
	// �Զ������߳�
	 public class auto_send_thread extends Thread {
		 
		 public void run(){
			// Log.d(TAG, "--------------->SB GO");
			 while(true) {
				 if(send_auto.isChecked() && node_send.isClickable()  ) {
					 String write_string = sendText.getText().toString();
					  //  write_string += "\r";
						if(write_string.length() == 0)
						{
							Log.d(TAG, "Send data is null!");
							continue;
						}
						if(send_hex.isChecked()) {
							write_string = write_string.replace(" ", "");
							if(write_string.matches(regEx)) {
								ret = mSeriport.write(help.toByteArray(write_string), write_string.length()/2);
							} else {
								;
							}
						} else {
							write_buffer = write_string.getBytes();
							ret = mSeriport.write(write_buffer, write_buffer.length);
						}
						
						if(ret > 0) {
							sum_tx += ret;
							
							Message msg = new Message();  
					 		msg.what = TX_display;  
					 		mHandler.sendMessage(msg);	
					 		
					 		if(_Dbug_ == 1)
								Log.d(TAG, "Write:" + write_string);
						}
						
					 try {  
					 	if(get_auto_time > 0)
					 		Thread.sleep(get_auto_time);  
					 	else
					 		Thread.sleep(2000);  
					 } catch (InterruptedException e) {  
			            e.printStackTrace();
					 }
				} else {
					try {  
					 	Thread.sleep(1000);  
					 } catch (InterruptedException e) {  
			            e.printStackTrace();
					 }
				}
			 }
		 }
	 }
	 
	// ���ݶ�ȡ�߳� ------------------------------------------------------->
	// read serialport data thread 
	public class read_thread extends Thread {
		private int       ret_receive = 0;
		
		@Override
		public void run() {
		 while (!Thread.currentThread().isInterrupted()) {  

			 if(mSeriport.isReady() > 0) {
				 ret_receive = mSeriport.wait_data();
				 if(ret_receive > 0){
					 ret_receive = mSeriport.read(read_buffer, 50, 30);// 40ms read
				 	 if (ret_receive > 0) { 
				 		String insert_data = null;
						try {
							insert_data = new String(read_buffer, 0, ret_receive, "ISO-8859-1");
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				 	
				 		synchronized (rxlock) {
				 			rx_queue.offer(insert_data);
				 			sum_rx += ret_receive;
				 		}
				 		Message msg = new Message();  
				 		msg.what = Message_display;  
				 		mHandler.sendMessage(msg);	
				 	}
			 	}
			 }
	        try {  
	            Thread.sleep(2);  
	        } catch (InterruptedException e) {  
	            e.printStackTrace();
	        }
		 }  
		}
	}
	// ���񰴼���----------------------------------------------------------------------------->
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			node_close.performClick();//return true;
			
			if(broadf == 1) {
				unregisterReceiver(curMreceiveBC);
				broadf = 0;
			}
		}
		return super.onKeyDown(keyCode,event);
	}
	
	protected void onDestroy() {
		super.onDestroy();
		
		node_close.performClick();
		
		if(broadf == 1) {
			unregisterReceiver(curMreceiveBC);
			broadf = 0;
		}
		
		Log.d(TAG, "----->start onDestroy");
	}
	
	protected void onStop() 
	{
		mWakeLock.release();

		node_close.performClick();
		Log.d(TAG, "------------>onStop");
		
		if(broadf == 1) {
			unregisterReceiver(curMreceiveBC);
			broadf = 0;
		}
		super.onStop();
	}
	
	protected void onResume()
	{
		mWakeLock.acquire(); 

		if(broadf == 0) {
			cur_Screen_Rece.addAction(Intent.ACTION_SCREEN_ON);
			cur_IntentFilter.addAction(Intent.ACTION_MEDIA_MOUNTED);
			cur_IntentFilter.addDataScheme("file");
			registerReceiver(curMreceiveBC, cur_IntentFilter);
			registerReceiver(curMreceiveBC, cur_Screen_Rece);
			broadf = 1;
			Log.d(TAG,"onResume-------->set broadcast receiver!");
		}
		Log.d(TAG,"-------->onResume!");
		super.onResume();
	}
	
	public void update_serialport()
	{
		update_device_node();
		/*
		Iterator<File> _itrDevice_ = getDevices("/dev/ttyUSB").iterator();
		
		while (_itrDevice_.hasNext()) {
			String cur_insert_name = _itrDevice_.next().getName();
			// Log.d("TAG", "--------->"+cur_insert_name);
			if(update_insert(cur_insert_name) == 0)
				allNode.add(cur_insert_name);
		}
		*/
	}
	
	public int update_insert(String insert)
	{
		for(int i = 0; i < node_adapter.getCount(); i++) { 
			if(insert.equals(node_adapter.getItem(i))) { 
				return -1; 
			} 
		} 
		
		return 0;
	}

	// ������ť�¼�------------------------------------------------------------------------------>
	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.equals(node_open)) {
			ret = mSeriport.open(part_serialPortNode, part_baud, part_data_size, part_stop_bit); // ��һ�����ڣ�
			Log.d(TAG, new String(part_serialPortNode) +"   baud:" + part_baud + "  "+"Button open rturn:"+ret);
			if(ret > 0) {
				node_close.setClickable(true);
				node_send.setClickable(true);
				node_open.setText("�Ѵ�");
				node_close.setText("�ر�");
				node_close.setEnabled(true);
				node_open.setEnabled(false);
				
				node_spinner.setEnabled(false);
				baud_spinner.setEnabled(false);
			} else {
				AlertDialog.Builder builder = new Builder(this); 
				builder.setTitle("����"); 
				builder.setPositiveButton("ȷ��", null); 
				// builder.setIcon(android.R.drawable.xx); 
				builder.setMessage("�豸���쳣" + "(" + ret + ")"); 
				builder.show(); 
			}
		} else if (v.equals(node_close)) {
			mSeriport.close();
			node_spinner.setEnabled(true);
			baud_spinner.setEnabled(true);
			node_send.setClickable(false);
			node_close.setEnabled(false);
			node_close.setText("�ѹر�");
			node_open.setText("��");
			node_open.setEnabled(true);
			mScrollView.scrollTo(0, curDisplay.getHeight());
		} else if (v.equals(node_save)) {
			if(sum_rx == 0) {
			//	return;
			}
			if(android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED)) {
				if(enableMKDir == true) {
					String   file_name = sd_dir + sDateFormat.format(new java.util.Date()) + ".log";
					File file = new File(file_name);
					try {
						file.createNewFile();
						Log.d(TAG, "new a log file!");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					if(file.exists()) {
						FileOutputStream out = null;
						try {
							out = new FileOutputStream(file, true);
							out.write(curDisplay.getText().toString().getBytes());
							out.flush();
							out.close();
							
							AlertDialog.Builder builder = new Builder(this);
							builder.setTitle("��ʾ"); 
							builder.setPositiveButton("ȷ��", null);
							builder.setMessage("���ݱ���ɹ�\nPath:"+file_name); 
							builder.show(); 
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							Log.d(TAG,"Write Log file faid!");
						}
					} else {
						Log.d(TAG,"MK Log file faid!");
					}
					Log.d(TAG,"Log file name:" + file_name);
				} else {
					Log.d(TAG,"there is not log dir.");
				}
			} else {
				AlertDialog.Builder builder = new Builder(this); 
				builder.setTitle("��ʾ"); 
				builder.setPositiveButton("ȷ��", null); 
				// builder.setIcon(android.R.drawable.xx); 
				builder.setMessage("�����SD�����Ա�������"); 
				builder.show(); 
			}
		}  else if (v.equals(node_clean)) {
			curDisplay.setText("");
			rxDisplay.setText("RX:0");
			txDisplay.setText("TX:0");
			sum_rx = 0;
			sum_tx = 0;
		} else if (v.equals(send_hex)){
			Log.d(TAG, "Button HEX");
		} else if (v.equals(node_send)) {
			Log.d(TAG, "Button send");
			String write_string = sendText.getText().toString();
		  //  write_string += "\r";
			if(write_string.length() == 0)
			{
				Log.d(TAG, "Send data is null!");
				return;
			}
			if(send_hex.isChecked()) {
				write_string = write_string.replace(" ", "");
				if(write_string.matches(regEx)) {
					ret = mSeriport.write(help.toByteArray(write_string), write_string.length()/2);
				} else {
					AlertDialog.Builder builder = new Builder(this); 
					builder.setTitle("����"); 
					builder.setPositiveButton("ȷ��", null); 
					// builder.setIcon(android.R.drawable.xx); 
					builder.setMessage("��ȷ�����������Ϊʮ������"); 
					builder.show(); 
				}
			} else {
				write_buffer = write_string.getBytes();
				ret = mSeriport.write(write_buffer, write_buffer.length);
			}
			
			if(ret > 0) {
				sum_tx += ret;
				txDisplay.setText("TX:" + sum_tx);
			}
			Log.d(TAG, "Write:" + write_string);
		} else if(v.equals(node_ext)) {// ��չ��UI���棻
			if(flag_ext == 0) 
			{
				ext_params.weight = 3.0f;
				cur_man_exten.setVisibility(View.VISIBLE);
				flag_ext = 1;
			}
			else if(flag_ext == 1)
			{
				ext_params.weight = 6.0f;
				cur_man_exten.setVisibility(View.GONE);
				findViewById(R.id.layout_fun).setLayoutParams(ext_params);
				flag_ext = 0;
				
				if(sp.getInt("GPS_KEY", 0) == 0)
					;
			}
		}else {
			Log.d(TAG, "Button select error");
		}
	}
	
	public void extpend_do(View src)
	{
		if(src.equals(cur_bd_power)) {	
						
						if(cur_bd_power.isChecked()) {	
			        		gpio_control(power_path[cur_module],1);
			        	} else {
			        		
			        		gpio_control(power_path[cur_module],0);
			        	}
						int curValue = 0;
						if(cur_bd_power.isChecked())
							curValue = 1;
						else
							curValue = 0;
						// 0:RFID�� 1�����룬2������֤��3��ָ�ƣ�
						switch(cur_module)
						{
							case  0:
								editor.putInt("RFID_KEY", curValue);
								break;
							case  1:
								editor.putInt("IR_KEY", curValue);
								break;
							case  2:
								editor.putInt("ID_KEY", curValue);
								break;
							case  3:
								editor.putInt("FG_KEY", curValue);
								break;
							default:
								Log.d(TAG, "no modue..");
						}
						editor.commit();
			       
		} else if(src.equals(cur_update)) {
			if(cur_update.isChecked()) {
				update_serialport();
				
				for(int k = 0, m = 0; k < 50000; k++)
					for(m = 0; m <= 15000; m++)
						;
				
				cur_update.setChecked(false);
			}
		}
	}
	
	public void gpio_control(String path, int state) {
		if (state == 0 || state == 1) {
			try {
				FileWriter localFileWriterOn = new FileWriter(new File(path));
				if (state == 1) {
					localFileWriterOn.write("1");
				} else if (state == 0) {
					localFileWriterOn.write("0");
				}
				localFileWriterOn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	
	
	
	// �㲥����ע����--------------------------------------->
	public class MreceiveBC extends BroadcastReceiver{
		
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			final String action = intent.getAction();
			int   flag_send = 0;
			
			Message msg = Message.obtain();
			Log.d(TAG, "Receive broadcast:" + action);
			if (Intent.ACTION_SCREEN_ON.equals(action)) {
				msg.what = ACTION_SCREEN_ON;
				flag_send =  1;
	        } else if(Intent.ACTION_SCREEN_OFF.equals(action)){
	            msg.what = ACTION_SCREEN_OFF;
	            flag_send = 1;
	            if(!node_open.isEnabled()) {
	            	open_state_before = 1;
	            }
	        } else if(Intent.ACTION_MEDIA_MOUNTED.equals(action)){
	        	flag_send = 0;
	        	// ������־Ŀ¼����SD���ϣ�
	        	if(!file.exists()) {
	    			enableMKDir = file.mkdirs();
	    			if(enableMKDir == false) {
	    				Log.d(TAG,"---->log dir mkdir fail!");
	    			}
	    		} else {
	    			enableMKDir = true;
	    			Log.d(TAG,"---->log dir is exists!");
	    		}
	        } else if(Intent.ACTION_MEDIA_EJECT.equals(action)){
	        	flag_send = 0;
	        	// ������־Ŀ¼����SD���ϣ�
	        	if(!file.exists()) {
	    			enableMKDir = file.mkdirs();
	    			if(enableMKDir == false) {
	    				Log.d(TAG,"---->log dir mkdir fail!");
	    			}
	    		} else {
	    			enableMKDir = true;
	    			Log.d(TAG,"---->log dir is exists!");
	    		}
	        } else {
	        	msg.what = ACTION_MESSAGE_ERROR;
	        }
			if (mHandler != null && flag_send == 1)
				mHandler.sendMessage(msg);
		}
	}
	
	private boolean settingIsOpen = true;
	
	//���ð�ť�ĵ���¼�
	public void clickSetting(View view){
		if(settingIsOpen){
			layout_setting.setVisibility(View.GONE);
			settingIsOpen = false;
			node_setting.setText("������");
			node_ext.setEnabled(false);
		}else{
			layout_setting.setVisibility(View.VISIBLE);
			settingIsOpen = true;
			node_setting.setText("�ر�����");
			node_ext.setEnabled(true);
		}
	}
	
}

